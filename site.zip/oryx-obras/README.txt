PROPUESTA WEB NO OFICIAL PARA ORYX OBRAS Y SERVICIOS

Sitio original: https://oryxobrasyservicios.com/
Contacto público: consultas@oryxobrasyservicios.com
Zona: Almería

Publicación manual en Netlify: arrastra la carpeta oryx-obras (la que contiene index.html) a la opción de deploy manual de Netlify.

Nota: imágenes de archivo ilustrativas cargadas desde Unsplash; requieren conexión a internet. Confirmar licencias y datos antes de uso definitivo. La demo lleva noindex/nofollow y aviso visible de propuesta no oficial.
