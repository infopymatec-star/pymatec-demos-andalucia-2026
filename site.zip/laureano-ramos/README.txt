PROPUESTA WEB NO OFICIAL PARA LAUREANO RAMOS

Sitio original: https://laureanoramos.es/
Contacto público: info@laureanoramos.es
Zona: Málaga y provincia

Publicación manual en Netlify: arrastra la carpeta laureano-ramos (la que contiene index.html) a la opción de deploy manual de Netlify.

Nota: imágenes de archivo ilustrativas cargadas desde Unsplash; requieren conexión a internet. Confirmar licencias y datos antes de uso definitivo. La demo lleva noindex/nofollow y aviso visible de propuesta no oficial.
